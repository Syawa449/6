package com.company;

public class Main {

    public static void main(String[] args) {
        String hello = "Hello";
        String world = "world";
        System.out.println(hello + " " + world + "!");
    }
}
